package eu.raspberrymods.fishmc.architectury;

public final class ExampleMod {
    public static final String MOD_ID = "fishmc";

    public static void init() {
        // Write common init code here.
    }
}
